DORSET CAR PHOTOGRAPHY WEBSITE

Files:
- index.html = the website
- style.css = the design
- script.js = tiny footer script
- assets/website-mockup.png = temporary background image

HOW TO USE:
1. Open index.html in a web browser to preview the site.
2. Replace the four gallery boxes in index.html with your own photos later.
3. Replace YOUR-EMAIL@example.com with the email address you want customers to use.
4. When you're ready to publish, use a website hosting service that allows you to upload HTML/CSS/JS files.

IMPORTANT:
Because you're 14, ask a parent/guardian to help with publishing the site, domain purchases, customer contact, bookings and payments.
